
	<footer class="footer-all">
	
		<div class="footer-in __80pc">

			<div class="footer-left">
				<ul>
					<li><a href="https://www.facebook.com/TetraPakBrasil" target="_blank"><img src="<?php bloginfo('stylesheet_directory')?>/build/img/facebook-logo.png" height="30" alt="Conheça o facebook da Tetra Pak" /></a></li>
					<li><a href="http://www.youtube.com/user/tetrapakbrasil" target="_blank"><img src="<?php bloginfo('stylesheet_directory')?>/build/img/youtube-logo.png" height="30" alt="Conheça o YouTube da Tetra Pak" /></a></li>
					<li><a href="<?php echo get_site_url(); ?>">Edição Atual</a></li>
					<li><a href="<?php echo get_site_url(); ?>/contato">Contato</a></li>
					<li><a href="<?php echo get_site_url(); ?>/pdf/acontece-jan-fev-2014.pdf" target="_blank">Versão PDF da revista</a></li>
				</ul>
			</div>

			<div class="hover-footer"></div>

			<div class="footer-right">
				<a href="http://www.tetrapak.com/br" target="_blank"><img src="<?php bloginfo('stylesheet_directory')?>/build/img/tetrapak-logo.png" alt="Tetra Pak, Protege o que é bom. Conheça nosso site" /></a>
			</div>
		</div>
	
	</footer><!-- #colophon -->

	<?php wp_footer(); ?>
</body>
</html>